#!/bin/bash
cd /root/exporters
./node_exporter --collector.systemd --collector.processes &
cd blackbox
./blackbox_exporter --config.file="./blackbox.yml" &
